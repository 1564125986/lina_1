## Major Honors & Awards

- 2023 National Science Fund for Excellent Young Scholars by NSFC (国家优青)
- 2021 Shenzhen Science and Technology Program for Excellent Young Scholar (深圳市优青)
- 2020 Guangdong Natural Science Funds for Distinguished Young Scholar (广东省杰青)
- 2019 Asia Graphics Young Researcher Award (亚洲图形学协会"青年学者奖")
- 2018 CSIAM GDC Young Researcher Award (几何设计与计算"青年学者奖")
- 2017 Young Elite Scientists Sponsorship Program by CAST (中科协"青年人才托举工程")
