## Journal editorial board

- [IEEE Transactions on Visualization and Computer Graphics](https://www.computer.org/csdl/journal/tg) Associate Editor: 2023-present
- [Computers and Graphics](https://www.editorialmanager.com/cag/default2.aspx) Associate Editor: 2022-present
- [IEEE Computer Graphics and Applications](https://www.computer.org/csdl/magazine/cg) Associate Editor: 2020-present
- [The Visual Computer](http://www.springer.com/computer/image+processing/journal/371) Associate Editor: 2018-2023
