## Ph.D. Students

- name: "Zeyu Huang"
  period: "2019-2024"
  position: "NIO"

- name: "Zihao Yan"
  period: "2016-2022"
  position: "Vivo"

## Master Students

- name: "Gengxin Liu"
  period: "2021-2024"
  position: "Tencent"

- name: "Zejia Su"
  period: "2021-2024"
  position: "ByteDance"

- name: "Jiexuan Xie"
  period: "2021-2024"
  position: "ByteDance"

- name: "Xiangkai Chen"
  period: "2020-2023"
  position: "Huawei"

- name: "Qian Sun"
  period: "2020-2023"
  position: "Lingxi Games"

- name: "Ziqi Ye"
  period: "2020-2023"
  position: "Baidu"

- name: "Bin Chen"
  period: "2019-2022"
  position: "Ph.D. student at Universität Konstanz"

- name: "Yuhan Tang"
  period: "2019-2022"
  position: "Tencent"

- name: "Luanmin Chen"
  period: "2018-2021"
  position: "Shopee"

- name: "Tingkai Sha"
  period: "2018-2021"
  position: "Netease Games"

- name: "Chunjin Song"
  period: "2017-2020"
  position: "Ph.D. student at University of British Columbia"

- name: "Hui Wang"
  period: "2017-2020"
  position: "Tencent"
